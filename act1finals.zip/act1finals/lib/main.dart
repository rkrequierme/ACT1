import 'package:flutter/material.dart';

void main() {
  runApp(const ProductDemoApp());
}

/// -------------------- AUTH SERVICE --------------------
class AuthService {
  AuthService._private();
  static final AuthService instance = AuthService._private();

  final List<User> _users = [];
  User? currentUser;

  bool register(String username, String password) {
    if (_users.any((u) => u.username == username)) return false;
    _users.add(User(username: username, password: password));
    return true;
  }

  bool login(String username, String password) {
    final user = _users.firstWhere(
          (u) => u.username == username && u.password == password,
      orElse: () => const User.empty(),
    );
    if (user.isEmpty) return false;
    currentUser = user;
    return true;
  }

  void logout() {
    currentUser = null;
  }
}

/// -------------------- MODELS --------------------
class User {
  final String username;
  final String password;
  const User({required this.username, required this.password});
  const User.empty() : username = '', password = '';
  bool get isEmpty => username.isEmpty && password.isEmpty;
}

class Product {
  final String name;
  final String description;
  double price;
  int stock;

  Product({
    required this.name,
    required this.description,
    required this.price,
    required this.stock,
  });
}

class CartItem {
  final Product product;
  int quantity;
  CartItem({required this.product, required this.quantity});
}

/// -------------------- SERVICES --------------------
class ProductService {
  ProductService._private();
  static final ProductService instance = ProductService._private();

  final List<Product> products = [];
}

class CartService {
  CartService._private();
  static final CartService instance = CartService._private();

  final List<CartItem> cart = [];

  void addToCart(Product product, int qty) {
    final existing = cart.firstWhere(
          (c) => identical(c.product, product),
      orElse: () => CartItem(product: product, quantity: 0),
    );

    if (existing.quantity == 0 && !cart.contains(existing)) {
      cart.add(CartItem(product: product, quantity: qty));
    } else {
      existing.quantity += qty;
    }
  }

  void updateQuantity(CartItem item, int newQty) {
    if (newQty <= 0) {
      cart.remove(item);
    } else {
      item.quantity = newQty;
    }
  }

  void removeFromCart(CartItem item) => cart.remove(item);

  void clearCart() => cart.clear();

  double get total => cart.fold(0.0, (sum, i) => sum + i.product.price * i.quantity);
}

/// -------------------- APP --------------------
class ProductDemoApp extends StatelessWidget {
  const ProductDemoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Product App Demo',
      theme: ThemeData(primarySwatch: Colors.blue),
      debugShowCheckedModeBanner: false,
      initialRoute: '/login',
      routes: {
        '/login': (context) => const LoginScreen(),
        '/register': (context) => const RegisterScreen(),
        '/menu': (context) => const MenuScreen(),
        '/add': (context) => const AddProductScreen(),
        '/list': (context) => const ProductListScreen(),
        '/cart': (context) => const CartScreen(),
      },
    );
  }
}

/// -------------------- LOGIN SCREEN --------------------
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _usernameC = TextEditingController();
  final _passwordC = TextEditingController();
  String? _error;

  void _tryLogin() {
    if (!_formKey.currentState!.validate()) return;
    final ok = AuthService.instance.login(_usernameC.text.trim(), _passwordC.text.trim());
    if (ok) {
      setState(() => _error = null);
      Navigator.pushReplacementNamed(context, '/menu');
    } else {
      setState(() => _error = 'Invalid username or password.');
    }
  }

  @override
  void dispose() {
    _usernameC.dispose();
    _passwordC.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Login')),
      body: Center(
        child: Card(
          margin: const EdgeInsets.all(24),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: SizedBox(
              width: 420,
              child: Form(
                key: _formKey,
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Text('Welcome — Please login', style: TextStyle(fontSize: 18)),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: _usernameC,
                    decoration: const InputDecoration(labelText: 'Username'),
                    validator: (v) => v == null || v.trim().isEmpty ? 'Required' : null,
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: _passwordC,
                    decoration: const InputDecoration(labelText: 'Password'),
                    obscureText: true,
                    validator: (v) => v == null || v.isEmpty ? 'Required' : null,
                  ),
                  const SizedBox(height: 12),
                  if (_error != null) Text(_error!, style: const TextStyle(color: Colors.red)),
                  Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    TextButton(
                      onPressed: () => Navigator.pushNamed(context, '/register'),
                      child: const Text('Create account'),
                    ),
                    ElevatedButton(onPressed: _tryLogin, child: const Text('Login'))
                  ]),
                ]),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// -------------------- REGISTER SCREEN --------------------
class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _formKey = GlobalKey<FormState>();
  final _usernameC = TextEditingController();
  final _passwordC = TextEditingController();
  String? _message;

  void _tryRegister() {
    if (!_formKey.currentState!.validate()) return;
    final success = AuthService.instance.register(_usernameC.text.trim(), _passwordC.text.trim());
    if (success) {
      setState(() {
        _message = 'Registration successful. You can now login.';
      });
      Future.delayed(const Duration(milliseconds: 800), () {
        if (!mounted) return;
        Navigator.pop(context);
      });
    } else {
      setState(() {
        _message = 'Username already exists. Choose another.';
      });
    }
  }

  @override
  void dispose() {
    _usernameC.dispose();
    _passwordC.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Register')),
      body: Center(
        child: Card(
          margin: const EdgeInsets.all(24),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: SizedBox(
              width: 420,
              child: Form(
                key: _formKey,
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Text('Create an account', style: TextStyle(fontSize: 18)),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: _usernameC,
                    decoration: const InputDecoration(labelText: 'Username'),
                    validator: (v) => v == null || v.trim().isEmpty ? 'Required' : null,
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: _passwordC,
                    decoration: const InputDecoration(labelText: 'Password'),
                    obscureText: true,
                    validator: (v) => (v == null || v.length < 4) ? 'Password must be ≥ 4 chars' : null,
                  ),
                  const SizedBox(height: 12),
                  if (_message != null)
                    Text(_message!, style: TextStyle(color: _message!.contains('successful') ? Colors.green : Colors.red)),
                  Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                    TextButton(onPressed: () => Navigator.pop(context), child: const Text('Back')),
                    ElevatedButton(onPressed: _tryRegister, child: const Text('Register')),
                  ])
                ]),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// -------------------- MENU SCREEN --------------------
class MenuScreen extends StatelessWidget {
  const MenuScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final username = AuthService.instance.currentUser?.username ?? 'Unknown';

    return Scaffold(
      appBar: AppBar(
        title: const Text('Menu'),
        actions: [
          IconButton(
            tooltip: 'Logout',
            icon: const Icon(Icons.exit_to_app),
            onPressed: () {
              AuthService.instance.logout();
              Navigator.pushReplacementNamed(context, '/login');
            },
          )
        ],
      ),
      body: Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text('Hello, $username', style: const TextStyle(fontSize: 20)),
          const SizedBox(height: 20),
          ElevatedButton.icon(icon: const Icon(Icons.add), label: const Text('Add Product'), onPressed: () => Navigator.pushNamed(context, '/add')),
          const SizedBox(height: 10),
          ElevatedButton.icon(icon: const Icon(Icons.list), label: const Text('View Products'), onPressed: () => Navigator.pushNamed(context, '/list')),
          const SizedBox(height: 10),
          ElevatedButton.icon(icon: const Icon(Icons.shopping_cart), label: const Text('Cart'), onPressed: () => Navigator.pushNamed(context, '/cart')),
        ]),
      ),
    );
  }
}

/// -------------------- ADD PRODUCT SCREEN --------------------
class AddProductScreen extends StatefulWidget {
  const AddProductScreen({super.key});

  @override
  State<AddProductScreen> createState() => _AddProductScreenState();
}

class _AddProductScreenState extends State<AddProductScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameC = TextEditingController();
  final _descC = TextEditingController();
  final _priceC = TextEditingController();
  final _stockC = TextEditingController();

  void _save() {
    if (!_formKey.currentState!.validate()) return;
    ProductService.instance.products.add(Product(
      name: _nameC.text,
      description: _descC.text,
      price: double.parse(_priceC.text),
      stock: int.parse(_stockC.text),
    ));
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Product added')));
    _nameC.clear();
    _descC.clear();
    _priceC.clear();
    _stockC.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Add Product')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(children: [
            TextFormField(controller: _nameC, decoration: const InputDecoration(labelText: 'Name'), validator: (v) => v!.isEmpty ? 'Required' : null),
            TextFormField(controller: _descC, decoration: const InputDecoration(labelText: 'Description')),
            TextFormField(controller: _priceC, decoration: const InputDecoration(labelText: 'Price'), keyboardType: TextInputType.number),
            TextFormField(controller: _stockC, decoration: const InputDecoration(labelText: 'Stock'), keyboardType: TextInputType.number),
            const SizedBox(height: 20),
            ElevatedButton(onPressed: _save, child: const Text('Save Product')),
          ]),
        ),
      ),
    );
  }
}
/// -------------------- PRODUCT LIST SCREEN --------------------
class ProductListScreen extends StatefulWidget {
  const ProductListScreen({super.key});

  @override
  State<ProductListScreen> createState() => _ProductListScreenState();
}

class _ProductListScreenState extends State<ProductListScreen> {
  Future<int?> _askQty(String title) async {
    final c = TextEditingController();
    return showDialog<int>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(title),
        content: TextField(
          controller: c,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'Quantity'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              final v = int.tryParse(c.text);
              if (v != null && v > 0) Navigator.pop(context, v);
            },
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final products = ProductService.instance.products;
    return Scaffold(
      appBar: AppBar(title: const Text('Product List')),
      body: products.isEmpty
          ? const Center(child: Text('No products yet.'))
          : ListView.builder(
        itemCount: products.length,
        itemBuilder: (context, i) {
          final p = products[i];
          return Card(
            child: ListTile(
              title: Text('${p.name} — ₱${p.price.toStringAsFixed(2)}'),
              subtitle: Text('${p.description}\nStock: ${p.stock}'),
              isThreeLine: true,
              trailing: Wrap(spacing: 6, children: [
                ElevatedButton(
                  onPressed: () async {
                    if (p.stock <= 0) {
                      ScaffoldMessenger.of(context)
                          .showSnackBar(const SnackBar(content: Text('Out of stock')));
                      return;
                    }
                    final qty = await _askQty('Buy ${p.name}');
                    if (qty != null && qty > 0) {
                      // 🟢 Just add to cart, don't decrease stock yet
                      CartService.instance.addToCart(p, qty);
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Added $qty × ${p.name} to cart')),
                      );
                      setState(() {});
                    }
                  },
                  child: const Text('Buy'),
                ),
                ElevatedButton(
                  onPressed: () async {
                    final qty = await _askQty('Replenish ${p.name}');
                    if (qty != null) {
                      p.stock += qty;
                      setState(() {});
                    }
                  },
                  child: const Text('Replenish'),
                ),
                IconButton(
                  icon: const Icon(Icons.delete, color: Colors.red),
                  onPressed: () {
                    ProductService.instance.products.removeAt(i);
                    setState(() {});
                  },
                ),
              ]),
            ),
          );
        },
      ),
    );
  }
}

/// -------------------- CART SCREEN --------------------
class CartScreen extends StatefulWidget {
  const CartScreen({super.key});

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  Future<int?> _askQty(String title) async {
    final c = TextEditingController();
    return showDialog<int>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(title),
        content: TextField(
          controller: c,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'Quantity'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              final v = int.tryParse(c.text);
              if (v != null && v > 0) Navigator.pop(context, v);
            },
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  void _checkout() {
    for (var item in CartService.instance.cart) {
      if (item.quantity > item.product.stock) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Not enough stock for ${item.product.name}')),
        );
        return;
      }
    }

    // 🟢 Now reduce stock after successful checkout
    for (var item in List<CartItem>.from(CartService.instance.cart)) {
      item.product.stock -= item.quantity;
    }

    CartService.instance.clearCart();
    setState(() {});
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Checkout complete')));
  }

  @override
  Widget build(BuildContext context) {
    final cart = CartService.instance.cart;
    return Scaffold(
      appBar: AppBar(title: const Text('Cart')),
      body: cart.isEmpty
          ? const Center(child: Text('Your cart is empty'))
          : Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: cart.length,
              itemBuilder: (context, i) {
                final item = cart[i];
                return Card(
                  child: ListTile(
                    title: Text(item.product.name),
                    subtitle: Text(
                      '₱${item.product.price} × ${item.quantity} = ₱${(item.product.price * item.quantity).toStringAsFixed(2)}',
                    ),
                    trailing: Wrap(spacing: 6, children: [
                      IconButton(
                        icon: const Icon(Icons.add_circle, color: Colors.green),
                        tooltip: 'Add quantity',
                        onPressed: () async {
                          final qty = await _askQty('Add more ${item.product.name}');
                          if (qty != null) {
                            item.quantity += qty;
                            setState(() {});
                          }
                        },
                      ),
                      IconButton(
                        icon: const Icon(Icons.remove_circle, color: Colors.red),
                        tooltip: 'Remove item',
                        onPressed: () {
                          CartService.instance.removeFromCart(item);
                          setState(() {});
                        },
                      ),
                    ]),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(children: [
              Text(
                'Total: ₱${CartService.instance.total.toStringAsFixed(2)}',
                style: const TextStyle(fontSize: 18),
              ),
              const SizedBox(height: 8),
              ElevatedButton(onPressed: _checkout, child: const Text('Checkout')),
            ]),
          ),
        ],
      ),
    );
  }
}

